import requests
from bs4 import BeautifulSoup
import pandas as pd
import random
import time
import re
import os


BASE_URL = "https://www.goldenpages.uz"
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36"
}
OUTPUT_DIR = "scraped_data"
os.makedirs(OUTPUT_DIR, exist_ok=True)  

def fetch_page(url, max_retries=3):
    """Fetch a webpage with retries."""
    for attempt in range(max_retries):
        try:
            response = requests.get(url, headers=HEADERS, timeout=10)
            response.raise_for_status()
            return BeautifulSoup(response.text, "html.parser")
        except requests.exceptions.RequestException as e:
            print(f"Error loading {url} (Attempt {attempt+1}/{max_retries}): {e}")
            time.sleep(random.uniform(2, 4))
    
    print(f"Skipping {url} after {max_retries} failed attempts")
    return None

def get_unlocked_data(business_id, data_type):
    """Fetches unlocked phone numbers OR emails via API."""
    api_type = "phones" if data_type == "phone" else "email"
    url = f"{BASE_URL}/scripts/company_data/?cid={business_id}&ctype={api_type}&clang=ru"
    
    try:
        response = requests.get(url, headers=HEADERS, timeout=10)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, "html.parser")
        
        if data_type == "email":
            emails = [item["href"].replace("mailto:", "").strip() for item in soup.select("li a[href^='mailto:']")]
            if not emails:
                emails = [item.text.strip() for item in soup.select("li") if "@" in item.text]
            if not emails:
                emails = re.findall(r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+", response.text)
            
            # Remove duplicate emails
            emails = list(set(emails))  
            return ", ".join(emails) if emails else ""
        else:
            data_list = [item.text.strip() for item in soup.select("li a")]
            return ", ".join(data_list) if data_list else ""
    
    except requests.exceptions.RequestException as e:
        print(f"Failed to load {data_type} for ID {business_id}: {e}")
        return ""

def get_last_page_number(soup):
    """Finds the last page number in pagination."""
    pagination = soup.select("ul.gp_pageNavigation a[data-page]")
    page_numbers = [int(a["data-page"]) for a in pagination if a["data-page"].isdigit()]
    return max(page_numbers) if page_numbers else 1

def get_business_links(category_name, category_url):
    """Scrapes all business links from a category (including multiple pages)."""
    business_links = []
    page_number = 1

    while True:
        current_url = f"{category_url}&Page={page_number}" if page_number > 1 else category_url
        print(f"Scraping: {category_name} - Page {page_number} -> {current_url}")

        soup = fetch_page(current_url)
        if not soup:
            break

        companies = soup.select("h3.h3.mb-0 a")
        if not companies and page_number > 1:
            print(f"No businesses found on page {page_number}. Stopping pagination.")
            break

        for company in companies:
            link = company.get("href")
            if link and link.startswith("/en/company"):
                full_link = BASE_URL + link
                business_links.append(full_link)

        last_page = get_last_page_number(soup)
        if page_number >= last_page:
            break

        page_number += 1
        time.sleep(random.uniform(2, 4))

    return business_links

def extract_business_details(category, business_url):
    """Scrapes full details from a single business page."""
    soup = fetch_page(business_url)
    if not soup:
        return None

    business_id_match = re.search(r"Id=(\d+)", business_url)
    business_id = business_id_match.group(1) if business_id_match else ""
    
    try:
        main_name = soup.select_one("h1").text.strip() if soup.select_one("h1") else ""
        secondary_name = soup.select_one("p.d-block.mb-0.mx-3.clr-blue").text.strip() if soup.select_one("p.d-block.mb-0.mx-3.clr-blue") else ""
        address = ", ".join(a.text.strip() for a in soup.select("div.gp_wrap_address p a")) if soup.select("div.gp_wrap_address p a") else ""
    
        phone_numbers = get_unlocked_data(business_id, "phone")
        email = get_unlocked_data(business_id, "email")
    
        website_tag = soup.select_one("ul.gp_icon_deML a[target='_blank']")
        website = website_tag.text.strip() if website_tag else ""
    
        description_tag = soup.select_one("div.col-12.mt-3.clr-black.fz-16")
        description = description_tag.text.strip() if description_tag else ""
    
        return {
            "Category": category,
            "Main Name": main_name,
            "Secondary Name": secondary_name,
            "Address": address,
            "Phone Numbers": phone_numbers,
            "Website": website,
            "Email": email,
            "Description": description
        }
    
    except Exception as e:
        print(f"Error extracting {business_url}: {e}")
        return None

def get_top_categories():
    """Scrapes the top 20 category links."""
    url = "https://www.goldenpages.uz/en/"
    soup = fetch_page(url)
    
    if not soup:
        print("Failed to load the main page.")
        return []

    header = soup.find(lambda tag: tag.name in ["h1", "h2", "h3"] and "TOP 20 Categories" in tag.get_text())
    if not header:
        print("The section 'TOP 20 Categories' was not found.")
        return []

    container = header.find_next_sibling()
    if not container or not container.find_all('a'):
        container = header.parent

    categories = []
    for a in container.find_all('a'):
        title = a.get_text(strip=True)
        link = a.get('href')

        if title and link and link.startswith("/en/rubrics"):
            full_link = BASE_URL + link
            categories.append({"Title": title, "Link": full_link})

    return categories[:20]  

def main():
    """Main function to scrape categories and their businesses."""
    print("Fetching top 20 categories...")
    categories = get_top_categories()

    if not categories:
        print("No categories found. Exiting.")
        return

    for category in categories:
        category_name = category["Title"]
        category_url = category["Link"]

        # Step 1: Get all business links for the category
        business_links = get_business_links(category_name, category_url)
        print(f"Found {len(business_links)} business links for {category_name}")

        # Step 2: Scrape details for each business
        business_data = []
        for link in business_links:
            print(f"Scraping details for {link}")
            details = extract_business_details(category_name, link)
            if details:
                business_data.append(details)
            time.sleep(random.uniform(2, 4))

        # Step 3: Save data for the category
        if business_data:
            output_file = os.path.join(OUTPUT_DIR, f"{category_name.replace(' ', '_')}.csv")
            df = pd.DataFrame(business_data)
            df.to_csv(output_file, index=False, encoding="utf-8")
            print(f"Data saved for {category_name} to {output_file}")

if __name__ == "__main__":
    main()
 
import aiohttp
import asyncio
import pandas as pd
import os
import re
import time
from tqdm.asyncio import tqdm
from bs4 import BeautifulSoup

# Base URL
BASE_URL = "https://www.goldenpages.uz"
HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36"}

# Output directory
OUTPUT_DIR = "scraped_data"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Async function to fetch a page
async def fetch_page(session, url, max_retries=3):
    for attempt in range(max_retries):
        try:
            async with session.get(url, headers=HEADERS, timeout=10) as response:
                response.raise_for_status()
                return await response.text()
        except Exception as e:
            await asyncio.sleep(2)  # Wait before retrying
    return None  # Return None if all retries fail

# Get unlocked phone/email using API
async def fetch_unlocked_data(session, business_id, data_type):
    api_url = f"{BASE_URL}/scripts/company_data/?cid={business_id}&ctype={data_type}&clang=ru"
    response_text = await fetch_page(session, api_url)
    if not response_text:
        return ""

    soup = BeautifulSoup(response_text, "html.parser")
    if data_type == "email":
        emails = {item["href"].replace("mailto:", "").strip() for item in soup.select("li a[href^='mailto:']")}
        return ", ".join(emails)
    else:
        phones = {item.text.strip() for item in soup.select("li a")}
        return ", ".join(phones)

# Get last page number in pagination
def get_last_page_number(soup):
    pagination = soup.select("ul.gp_pageNavigation a[data-page]")
    page_numbers = [int(a["data-page"]) for a in pagination if a["data-page"].isdigit()]
    return max(page_numbers) if page_numbers else 1

# Get all business links from a category
async def get_business_links(session, category_name, category_url):
    business_links = []
    first_page_html = await fetch_page(session, category_url)
    if not first_page_html:
        return []

    soup = BeautifulSoup(first_page_html, "html.parser")
    last_page = get_last_page_number(soup)

    for page_number in range(1, last_page + 1):
        current_url = f"{category_url}&Page={page_number}" if page_number > 1 else category_url
        page_html = await fetch_page(session, current_url)
        if not page_html:
            continue

        soup = BeautifulSoup(page_html, "html.parser")
        companies = soup.select("h3.h3.mb-0 a")
        business_links.extend([BASE_URL + c.get("href") for c in companies if c.get("href").startswith("/en/company")])

    return business_links

# Extract business details
async def extract_business_details(session, category, business_url):
    business_html = await fetch_page(session, business_url)
    if not business_html:
        return None

    soup = BeautifulSoup(business_html, "html.parser")
    business_id_match = re.search(r"Id=(\d+)", business_url)
    business_id = business_id_match.group(1) if business_id_match else ""

    main_name = soup.select_one("h1").text.strip() if soup.select_one("h1") else ""
    secondary_name = soup.select_one("p.d-block.mb-0.mx-3.clr-blue").text.strip() if soup.select_one("p.d-block.mb-0.mx-3.clr-blue") else ""
    address = ", ".join(a.text.strip() for a in soup.select("div.gp_wrap_address p a")) if soup.select("div.gp_wrap_address p a") else ""

    phone_numbers = await fetch_unlocked_data(session, business_id, "phones")
    email = await fetch_unlocked_data(session, business_id, "email")

    website_tag = soup.select_one("ul.gp_icon_deML a[target='_blank']")
    website = website_tag.text.strip() if website_tag else ""

    description_tag = soup.select_one("div.col-12.mt-3.clr-black.fz-16")
    description = description_tag.text.strip() if description_tag else ""

    return {
        "Category": category,
        "Main Name": main_name,
        "Secondary Name": secondary_name,
        "Address": address,
        "Phone Numbers": phone_numbers,
        "Website": website,
        "Email": email,
        "Description": description
    }

# Get the top categories
async def get_top_categories(session):
    url = f"{BASE_URL}/en/"
    html = await fetch_page(session, url)
    if not html:
        return []

    soup = BeautifulSoup(html, "html.parser")
    header = soup.find(lambda tag: tag.name in ["h1", "h2", "h3"] and "TOP 20 Categories" in tag.get_text())
    if not header:
        return []

    container = header.find_next_sibling() or header.parent
    categories = [{"Title": a.text.strip(), "Link": BASE_URL + a.get("href")} for a in container.find_all("a") if a.get("href").startswith("/en/rubrics")]

    return categories[:20]

# Scrape all businesses in a category
async def scrape_category(session, category):
    category_name = category["Title"]
    category_url = category["Link"]

    business_links = await get_business_links(session, category_name, category_url)
    if not business_links:
        return

    business_data = []
    tasks = [extract_business_details(session, category_name, link) for link in business_links]
    for business in tqdm(asyncio.as_completed(tasks), total=len(tasks), desc=f"Scraping {category_name}", leave=True):
        details = await business
        if details:
            business_data.append(details)

    if business_data:
        df = pd.DataFrame(business_data)
        output_file = os.path.join(OUTPUT_DIR, f"{category_name.replace(' ', '_')}.csv")
        df.to_csv(output_file, index=False, encoding="utf-8")
        print(f"Data saved for {category_name} to {output_file}")

# Main function
async def main():
    async with aiohttp.ClientSession() as session:
        categories = await get_top_categories(session)
        if not categories:
            print("No categories found. Exiting.")
            return

        for category in categories:
            await scrape_category(session, category)

# Run script
if __name__ == "__main__":
    asyncio.run(main())
